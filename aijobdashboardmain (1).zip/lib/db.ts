// Mock database functions - no MySQL required
export async function query(sql: string, params?: any[]) {
  // Return mock data based on the query type
  if (sql.includes("articles")) {
    return [
      {
        id: 1,
        title: "AI Automation Reshapes Manufacturing Jobs",
        content: "Recent studies show that AI automation is transforming manufacturing roles...",
        category: "Manufacturing",
        date: "2024-01-15",
        impact_score: 8.5,
        jobs_affected: 125000,
        skills_required: "Machine Learning, Robotics, Data Analysis",
      },
      {
        id: 2,
        title: "Healthcare AI Creates New Diagnostic Roles",
        content: "AI-powered diagnostic tools are creating new opportunities in healthcare...",
        category: "Healthcare",
        date: "2024-01-10",
        impact_score: 7.2,
        jobs_affected: 85000,
        skills_required: "AI Ethics, Medical Imaging, Data Science",
      },
      {
        id: 3,
        title: "Financial Services Embrace AI Trading",
        content: "Investment firms are increasingly relying on AI for trading decisions...",
        category: "Finance",
        date: "2024-01-08",
        impact_score: 9.1,
        jobs_affected: 95000,
        skills_required: "Algorithmic Trading, Risk Analysis, Machine Learning",
      },
    ]
  }

  // Return empty array for other queries
  return []
}

export async function getConnection() {
  // Mock connection - no actual database
  return {
    execute: query,
    end: () => Promise.resolve(),
  }
}
