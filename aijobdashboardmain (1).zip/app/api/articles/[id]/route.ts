import { NextResponse } from "next/server"

// Mock articles data
const mockArticles = [
  {
    id: 1,
    title: "AI Automation Reshapes Manufacturing Jobs",
    content:
      "Recent studies show that AI automation is transforming manufacturing roles, with 65% of factory workers requiring new skills training. Companies are investing heavily in retraining programs to help workers adapt to AI-enhanced production lines. The shift is creating new opportunities for technicians who can work with robotic systems and data analysts who can optimize production processes.",
    category: "Manufacturing",
    date: "2024-01-15",
    impact_score: 8.5,
    jobs_affected: 125000,
    skills_required: "Machine Learning, Robotics, Data Analysis",
    summary: "Manufacturing sector sees major AI integration requiring workforce retraining.",
    author: "Dr. Emily Chen",
    reading_time: 5,
    tags: ["AI", "Manufacturing", "Automation", "Skills Training"],
  },
  {
    id: 2,
    title: "Healthcare AI Creates New Diagnostic Roles",
    content:
      "AI-powered diagnostic tools are creating new opportunities in healthcare, with radiologists and pathologists working alongside AI systems to improve accuracy and speed of diagnoses. This collaboration is leading to better patient outcomes while requiring medical professionals to develop new technical skills.",
    category: "Healthcare",
    date: "2024-01-10",
    impact_score: 7.2,
    jobs_affected: 85000,
    skills_required: "AI Ethics, Medical Imaging, Data Science",
    summary: "Healthcare professionals adapting to AI-assisted diagnostic workflows.",
    author: "Dr. Michael Rodriguez",
    reading_time: 4,
    tags: ["Healthcare", "AI Diagnostics", "Medical Technology"],
  },
  {
    id: 3,
    title: "Financial Services Embrace AI Trading",
    content:
      "Investment firms are increasingly relying on AI for trading decisions, creating demand for professionals who can bridge finance and technology expertise. The integration of machine learning algorithms in trading strategies is reshaping the financial landscape.",
    category: "Finance",
    date: "2024-01-08",
    impact_score: 9.1,
    jobs_affected: 95000,
    skills_required: "Algorithmic Trading, Risk Analysis, Machine Learning",
    summary: "Finance sector rapidly adopting AI for trading and risk management.",
    author: "Sarah Johnson",
    reading_time: 6,
    tags: ["Finance", "AI Trading", "FinTech", "Machine Learning"],
  },
]

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    // Find mock article by ID
    const article = mockArticles.find((article) => article.id === id)

    if (!article) {
      return NextResponse.json({ error: "Article not found" }, { status: 404 })
    }

    return NextResponse.json(article)
  } catch (error) {
    console.error("Error fetching article:", error)
    return NextResponse.json({ error: "Failed to fetch article" }, { status: 500 })
  }
}
