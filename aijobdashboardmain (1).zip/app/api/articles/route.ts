import { NextResponse } from "next/server"

// Mock articles data
const mockArticles = [
  {
    id: 1,
    title: "AI Automation Reshapes Manufacturing Jobs",
    content:
      "Recent studies show that AI automation is transforming manufacturing roles, with 65% of factory workers requiring new skills training. Companies are investing heavily in retraining programs to help workers adapt to AI-enhanced production lines.",
    category: "Manufacturing",
    date: "2024-01-15",
    impact_score: 8.5,
    jobs_affected: 125000,
    skills_required: "Machine Learning, Robotics, Data Analysis",
    summary: "Manufacturing sector sees major AI integration requiring workforce retraining.",
  },
  {
    id: 2,
    title: "Healthcare AI Creates New Diagnostic Roles",
    content:
      "AI-powered diagnostic tools are creating new opportunities in healthcare, with radiologists and pathologists working alongside AI systems to improve accuracy and speed of diagnoses.",
    category: "Healthcare",
    date: "2024-01-10",
    impact_score: 7.2,
    jobs_affected: 85000,
    skills_required: "AI Ethics, Medical Imaging, Data Science",
    summary: "Healthcare professionals adapting to AI-assisted diagnostic workflows.",
  },
  {
    id: 3,
    title: "Financial Services Embrace AI Trading",
    content:
      "Investment firms are increasingly relying on AI for trading decisions, creating demand for professionals who can bridge finance and technology expertise.",
    category: "Finance",
    date: "2024-01-08",
    impact_score: 9.1,
    jobs_affected: 95000,
    skills_required: "Algorithmic Trading, Risk Analysis, Machine Learning",
    summary: "Finance sector rapidly adopting AI for trading and risk management.",
  },
  {
    id: 4,
    title: "Education Technology Transforms Learning",
    content:
      "AI tutoring systems and personalized learning platforms are changing how education is delivered, requiring teachers to develop new digital skills.",
    category: "Education",
    date: "2024-01-05",
    impact_score: 6.8,
    jobs_affected: 150000,
    skills_required: "Educational Technology, AI Literacy, Digital Pedagogy",
    summary: "Educational institutions integrating AI to enhance learning experiences.",
  },
  {
    id: 5,
    title: "Retail Automation Changes Customer Service",
    content:
      "Chatbots and AI-powered customer service tools are transforming retail, while creating new roles in AI management and customer experience design.",
    category: "Retail",
    date: "2024-01-03",
    impact_score: 7.5,
    jobs_affected: 200000,
    skills_required: "Customer Experience Design, AI Management, Data Analytics",
    summary: "Retail sector balancing automation with human-centered customer service.",
  },
]

export async function GET() {
  try {
    // Return mock data instead of database query
    return NextResponse.json(mockArticles)
  } catch (error) {
    console.error("Error fetching articles:", error)
    return NextResponse.json({ error: "Failed to fetch articles" }, { status: 500 })
  }
}
